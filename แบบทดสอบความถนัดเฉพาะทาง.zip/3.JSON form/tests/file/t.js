var tests = [
  {
    name: 'minimal',
    jsonform: {
      schema: {
        filemeup: {
          type: 'string',
          title: 'Title'
        }
      },
      form: [
        {
          key: 'filemeup',
          type: 'file'
        }
      ]
    }
  }
];
