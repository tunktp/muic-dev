$("document").ready(function(){

    $('#myForm').submit(function(e){
  
     // To stop the default behavior, a # will be added to the URL in the address bar.
     e.preventDefault();
  
     var datastring = $("#myForm").serialize();
  
      $.ajax({
  
        type: "POST",
        dataType: "json",
        url: "get_json.pl",
        data: datastring,
  
        success: function(data) {
  
        var stable =
         '<div class="popup-inner">'+
         ' <h2>Results</h2>'+
            ' <div>';
  
        $.each( data, function( key, value ) {
          stable+= '<p><a href="results_1.pl?name=' + value.name + '&gender=' + value.gender + ' "id="btnSend">Name: ' + value.name + '</a> | ' + 'Gender: ' + value.gender + '</p>';
  
      });
  
    stable += 
        ' </div>'+
            '<p><a data-popup-close="popup" href="#">Close</a></p>'+
            '<a class="popup-close" data-popup-close="popup" href="#">x</a>'+
        '</div>';
  
     // Popup will be called here and opended in the div below 
     $('#popup').append(stable).fadeIn(350);
  
        // This function will close the popup on click.
        $('[data-popup-close]').on('click', function(e)  {
  
          var targeted_popup_class = jQuery(this).attr('data-popup-close');
      $('#'+targeted_popup_class).fadeOut(350);
      // Or use the id from the div below to close it.
      //$('#popup').fadeOut(350);
          e.preventDefault();
  
        });
  
  
     },
     error: function() {
      alert('Error handing data');
     }
  
     });
  
  });
  });